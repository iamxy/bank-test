select count(*) from lineitem;
