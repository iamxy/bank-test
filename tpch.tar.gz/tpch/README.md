# TPC-H Test

TPC-H Test, special for MYSQL and TIDB
