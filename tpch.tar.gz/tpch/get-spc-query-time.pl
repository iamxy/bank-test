#!/usr/bin/perl -w
use strict;
use warnings;
#
# Execute all random queries, except 18.sql
#

my $output = "results/query-time.data";
my ($passwd, $port) = ($ARGV[1], $ARGV[0]);
my @sqls = ("1.sql", "14.sql", "ff0.sql", "ff1.sql");

foreach my $sql (@sqls) {
    print "query $sql\n";
    # system("./restart-mysql.pl");
    system("echo query: $sql >> $output");
    if( !defined($passwd) ) {
        system("./get-query-time.pl queries/$sql tpch $port >> $output");
    }else {
        system("./get-query-time.pl queries/$sql tpch $port $passwd >> $output");
    }
}
